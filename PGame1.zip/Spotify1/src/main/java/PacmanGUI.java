/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FiercePC
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PacmanGUI extends JFrame {

    private PacmanBoard pacmanBoard;
    private MenuPanel menuPanel;

    public PacmanGUI() {
        menuPanel = new MenuPanel();
        add(menuPanel);

        setSize(600, 600);
        setLocationRelativeTo(null);
        setTitle("Pacman Game");

        menuPanel.getPlayButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        menuPanel.getQuitButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

private void startGame() {
    remove(menuPanel);
    pacmanBoard = new PacmanBoard();
    add(pacmanBoard);

    addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            pacmanBoard.handleKeyPress(evt);
        }
    });

    pacmanBoard.requestFocusInWindow(); 
    setFocusable(true);
    setVisible(true);
    revalidate();
    repaint();
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PacmanGUI pacmanGame = new PacmanGUI();
            pacmanGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Add this line
            pacmanGame.setVisible(true); 
        });
    }

    class MenuPanel extends JPanel {
        private JButton playButton;
        private JButton quitButton;

        public MenuPanel() {
            setLayout(new BorderLayout());

            JLabel pacmanLabel = new JLabel("Pacman", SwingConstants.CENTER);
            pacmanLabel.setFont(new Font("Arial", Font.BOLD, 40));
            add(pacmanLabel, BorderLayout.NORTH);

            JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 20));
            playButton = new JButton("Play");
            quitButton = new JButton("Quit");
            buttonPanel.add(playButton);
            buttonPanel.add(quitButton);
            add(buttonPanel, BorderLayout.CENTER);
        }

        public JButton getPlayButton() {
            return playButton;
        }

        public JButton getQuitButton() {
            return quitButton;
        }
    }
}