/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FiercePC
 */
import java.awt.Color;
import java.awt.Graphics;

public class Coin {

    private int x, y;
    private boolean collected;

    public Coin(int x, int y) {
        this.x = x;
        this.y = y;
        this.collected = false;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean isCollected() {
        return collected;
    }

    public void setCollected(boolean collected) {
        this.collected = collected;
    }

public void reset(int[][] walls) {
    // Resets the coin's position
    // Ensures that the new position is not in the border or within walls
    do {
        x = generateRandomPosition(50, 550);  // Adjust the range of where the coins can spawn at
        y = generateRandomPosition(50, 550);
    } while (isPositionInvalid(walls));

    collected = false;
}

    private int generateRandomPosition(int min, int max) {
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    private boolean isPositionInvalid(int[][] walls) {
        // Checks if the coin's position is within the border or collides with walls
        for (int[] wall : walls) {
            int wallX = wall[0];
            int wallY = wall[1];
            int wallWidth = wall[2];
            int wallHeight = wall[3];

            if (x >= wallX && x <= wallX + wallWidth && y >= wallY && y <= wallY + wallHeight) {
                return true; // Coin spawned in a wall
            }
        }

        if (x <= 20 || x >= 580 || y <= 20 || y >= 580) {
            return true; // Coin spawned in the border
        }

        return false; // Valid position
    }

    public void draw(Graphics g) {
        if (!collected) {
            g.setColor(Color.YELLOW);
            g.fillOval(x, y, 10, 10); // Adjusts the size of the coins
        }
    }
}