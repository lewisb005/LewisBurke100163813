/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FiercePC
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class PacmanBoard extends JPanel {

    private PacmanPlayer pacmanPlayer;
    private List<Ghost> ghosts;
    private Timer timer;
    private List<Coin> coins; 
    private int score;
    private boolean paused;
    private int[][] walls; 

    public PacmanBoard() {
        pacmanPlayer = new PacmanPlayer(50, 50);
        ghosts = new ArrayList<>();
        ghosts.add(new Ghost(300, 300)); // Initial ghost at (300, 300)
        paused = false;

        // walls in map (xywh adjusting
walls = new int[][] {
    {0, -16, 600, 20},  // Top border
    {-16, 0, 20, 600},  // Left border
    {580, 0, 20, 600},  // Right border
    {0, 557, 600, 20},  // Bottom border
    // x, y, width, height
    // Vertical walls
    {50, 50, 7, 200},
    {50, 310, 7, 200},
    {160, 50, 7, 200},
    {175, 310, 7, 200},
    {290, 150, 7, 200},
    {400, 50, 7, 200},
    {400, 354, 7, 150},
    {525, 50, 7, 200},
    {525, 354, 7, 155},

    // Horizontal walls
    {100, 50, 150, 7},
    {100, 200, 150, 7},
    {360, 300, 200, 7},
    {100, 400, 150, 7},
    {300, 500, 200, 7},
    {250, 100, 100, 7},
    {250, 250, 100, 7},
    {300, 400, 100, 7},
};

        setPreferredSize(new Dimension(600, 600));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
        });

        coins = new ArrayList<>();
        // 30 more coins
        for (int i = 0; i < 30; i++) {
            int randomX, randomY;

            do {
                randomX = (int) (Math.random() * 600);
                randomY = (int) (Math.random() * 600);
            } while (coinOnWall(randomX, randomY));

            coins.add(new Coin(randomX, randomY));
        }
        score = 0;

        timer = new Timer(30, e -> {
            if (!paused) {
                handleGameLogic();
                repaint();
            }
        });
        timer.start();
    }

    public void handleKeyPress(KeyEvent evt) {
        char newDirection = 'L';

        switch (evt.getKeyChar()) {
            case 'a':
                newDirection = 'L';
                break;
            case 'd':
                newDirection = 'R';
                break;
            case 'w':
                newDirection = 'U';
                break;
            case 's':
                newDirection = 'D';
                break;
            case KeyEvent.VK_ESCAPE:
                togglePause();
                break;
        }

        pacmanPlayer.setDesiredDirection(newDirection);
    }

    private void togglePause() {
        paused = !paused;
        if (paused) {
            timer.stop();
        } else {
            timer.start();
        }
    }

    public boolean collidesWithGhost(Ghost ghost) {
        int playerRadius = 20;
        int ghostRadius = 20;

        int playerCenterX = pacmanPlayer.getX() + playerRadius;
        int playerCenterY = pacmanPlayer.getY() + playerRadius;

        int ghostCenterX = ghost.getX() + ghostRadius;
        int ghostCenterY = ghost.getY() + ghostRadius;

        double distance = Math.sqrt(Math.pow(playerCenterX - ghostCenterX, 2) + Math.pow(playerCenterY - ghostCenterY, 2));

        return distance < playerRadius + ghostRadius;
    }

    private int collectedCoins = 0;

    private void handleGameLogic() {
        pacmanPlayer.move(walls);

        for (int[] wall : walls) {
            int wallX = wall[0];
            int wallY = wall[1];
            int wallWidth = wall[2];
            int wallHeight = wall[3];

            if (pacmanPlayer.getX() < wallX + wallWidth && pacmanPlayer.getX() + 40 > wallX && pacmanPlayer.getY() < wallY + wallHeight
                    && pacmanPlayer.getY() + 40 > wallY) {
                pacmanPlayer.undoMove();
            }
        }

        for (Ghost ghost : ghosts) {
            ghost.chasePlayer(pacmanPlayer, walls);

            if (collidesWithGhost(ghost)) {
                handleGameOver();
                return;
            }
        }

        // coin collection handling
        for (Coin coin : coins) {
            if (pacmanPlayer.collectsCoin(coin)) {
                score++;
                coin.reset(walls); // Resets the coin's position
                // Spawn ghosts based on the player's score
                spawnGhostsBasedOnScore();
            }
        }
    }

    private void spawnGhostsBasedOnScore() {
        
        // One ghost is already pre-spawned (hence the immediate second, rather than first.
        // Spawns a second ghost when the player gets 10 coins
        if (score == 10 && ghosts.size() < 2) {
            spawnGhost();
        }
        // Spawns a third ghost when the player gets 30 coins
        if (score == 30 && ghosts.size() < 3) {
            spawnGhost();
        }
        // Spawns a fourth ghost when the player gets 50 coins
        if (score == 50 && ghosts.size() < 4) {
            spawnGhost();
        }
        // Spawns a fifth ghost when the player gets 75 coins
        if (score == 75 && ghosts.size() < 5) {
          spawnGhost();
        }
    }

private void spawnGhost() {
    int ghostRadius = 20;
    int maxAttempts = 100; // if the ghost cant spawn in a safe location after 100 attempts, the ghost doesn't spawn (in the walls/border avoids)

    for (int attempt = 0; attempt < maxAttempts; attempt++) {
        int randomX = (int) (Math.random() * (600 - 2 * ghostRadius));
        int randomY = (int) (Math.random() * (600 - 2 * ghostRadius));

        // Check if the randomly generated position is actually valid
        if (isValidGhostSpawn(randomX, randomY)) {
            Ghost newGhost = new Ghost(randomX, randomY);
            ghosts.add(newGhost);
            return; // Exits the loop once a valid position is found
        }
    }
}
    
    private boolean isValidGhostSpawn(int x, int y) {
    int ghostRadius = 20;

    int ghostLeft = x;
    int ghostRight = x + 2 * ghostRadius;
    int ghostTop = y;
    int ghostBottom = y + 2 * ghostRadius;

    for (int[] wall : walls) {
        int wallLeft = wall[0];
        int wallRight = wall[0] + wall[2];
        int wallTop = wall[1];
        int wallBottom = wall[1] + wall[3];

        if (ghostRight > wallLeft && ghostLeft < wallRight && ghostBottom > wallTop && ghostTop < wallBottom) {
            return false; // Avoiding collision with wall
        }
    }

    return true;
}

    private void handleGameOver() {
        JOptionPane.showMessageDialog(this, "Game Over - You Lost!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
        pacmanPlayer.reset();
        ghosts.clear();
        resetCoins();
        score = 0;
    }

    private void resetCoins() {
        for (Coin coin : coins) {
            coin.reset(walls);
        }
    }
    
    private boolean coinOnWall(int x, int y) {
        for (int[] wall : walls) {
            int wallX = wall[0];
            int wallY = wall[1];
            int wallWidth = wall[2];
            int wallHeight = wall[3];

            if (x >= wallX && x < wallX + wallWidth && y >= wallY && y < wallY + wallHeight) {
                return true; 
            }
        }
        return false; // This boolean is attempting to stop coins spawning in points where the player can't grab them (on walls/map border etc)
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draws background (black)
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Draws the walls
        g.setColor(Color.BLUE);
        for (int[] wall : walls) {
            g.fillRect(wall[0], wall[1], wall[2], wall[3]);
        }


        // Draws the pacman player
        g.setColor(Color.YELLOW);
        int startAngle = 0;
        int arcAngle = 0;

        switch (pacmanPlayer.getCurrDirection()) {
            case 'L':
                startAngle = 225;
                arcAngle = 270;
                break;
            case 'R':
                startAngle = 45;
                arcAngle = 270;
                break;
            case 'U':
                startAngle = 135;
                arcAngle = 270;
                break;
            case 'D':
                startAngle = -45;
                arcAngle = 270;
                break;
        }

        g.fillArc(pacmanPlayer.getX(), pacmanPlayer.getY(), 40, 40, startAngle, arcAngle);

        // Draws ghosts
        g.setColor(Color.RED);
        for (Ghost ghost : ghosts) {
            g.fillOval(ghost.getX(), ghost.getY(), 40, 40);
        }

        // Draws coins
        g.setColor(Color.YELLOW);
        for (Coin coin : coins) {
            g.fillOval(coin.getX(), coin.getY(), 10, 10); // Adjust the size as needed
        }

        // Displays score
        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 10, 20);
    }
}