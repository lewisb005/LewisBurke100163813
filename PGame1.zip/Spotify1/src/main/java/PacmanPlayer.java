/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FiercePC
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.*;
import java.util.List;

public class PacmanPlayer {

    public int x, y;
    private char currDirection;
    private char direction;
    private char desiredDirection;
    private int score;

    public PacmanPlayer(int startX, int startY) {
        x = startX;
        y = startY;
        currDirection = 'L';
        direction = 'L';
        desiredDirection = 'L';
        score = 0;
    }
    
        public void collectCoins(List<Coin> coins) {
        for (Coin coin : coins) {
            if (!coin.isCollected() && x == coin.getX() && y == coin.getY()) {
                coin.setCollected(true);
                score += 10; // adjust score
            }
        }
    }

    public int getScore() {
        return score;
    }
    
        public boolean collectsCoin(Coin coin) {
        int playerRadius = 20;
        int coinRadius = 5; // Adjust the size of the coins on the map

        int playerCenterX = x + playerRadius;
        int playerCenterY = y + playerRadius;

        int coinCenterX = coin.getX() + coinRadius;
        int coinCenterY = coin.getY() + coinRadius;

        double distance = Math.sqrt(Math.pow(playerCenterX - coinCenterX, 2) + Math.pow(playerCenterY - coinCenterY, 2));

        return distance < playerRadius + coinRadius;
    }
    

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setDesiredDirection(char newDirection) {
        desiredDirection = newDirection;
    }

    public void reset() {
        // Reset the player's position or any other necessary attributes
        x = 50;
        y = 50;
        currDirection = 'L';
        direction = 'L';
        desiredDirection = 'L';
    }

public void move(int[][] walls) {
    int newX = x;
    int newY = y;

    // Updates the current direction before moving
    currDirection = desiredDirection;

    switch (desiredDirection) {
        case 'L':
            newX -= 5;
            break;
        case 'R':
            newX += 5;
            break;
        case 'U':
            newY -= 5;
            break;
        case 'D':
            newY += 5;
            break;
    }

    // Checks for collisions or boundaries before updating the position of the player
    if (isValidMove(newX, newY, walls)) {
        x = newX;
        y = newY;
        // Updates the current direction to the desired direction
        direction = desiredDirection;
    }
}

    public void undoMove() {
        // Reverts the player's position based on the last move
        switch (direction) {
            case 'L':
                x += 5;
                break;
            case 'R':
                x -= 5;
                break;
            case 'U':
                y += 5;
                break;
            case 'D':
                y -= 5;
                break;
        }
    }

    public char getCurrDirection() {
        return currDirection;
    }

    private boolean isValidMove(int newX, int newY, int[][] walls) {
        // Checks if the new position is within the allowed bounds and doesn't collide with walls
        int playerRadius = 20; // Adjust the value based on the playersize

        int playerLeft = newX;
        int playerRight = newX + 2 * playerRadius;
        int playerTop = newY;
        int playerBottom = newY + 2 * playerRadius;

        // Checks if the new position collides with walls
        for (int[] wall : walls) {
            int wallLeft = wall[0];
            int wallRight = wall[0] + wall[2];
            int wallTop = wall[1];
            int wallBottom = wall[1] + wall[3];

            if (playerRight > wallLeft && playerLeft < wallRight && playerBottom > wallTop && playerTop < wallBottom) {
                return false; // wall collision
            }
        }

        // Check if the new position is within the allowed bounds
        return newX >= 0 && newX + 2 * playerRadius <= 600 && newY >= 0 && newY + 2 * playerRadius <= 600;
    }

    public void draw(Graphics g) {
        // controls the playermodel, what way the player is looking via wasd
        g.setColor(Color.YELLOW);

        int startAngle = 0;
        int arcAngle = 0;

        switch (currDirection) {
            case 'L':
                startAngle = 225;
                arcAngle = 270;
                break;
            case 'R':
                startAngle = 45;
                arcAngle = 270;
                break;
            case 'U':
                startAngle = 135;
                arcAngle = 270;
                break;
            case 'D':
                startAngle = -45;
                arcAngle = 270;
                break;
        }

        g.fillArc(x, y, 40, 40, startAngle, arcAngle);
    }
}