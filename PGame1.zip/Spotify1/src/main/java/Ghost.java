/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author FiercePC
 */
import java.awt.Graphics;
import java.util.*;

public class Ghost {
    private int x, y;
    private int startX, startY; 
    private int speedMultiplier = 2; // Adjusts the ghosts speed (multiplier)

    public Ghost(int startX, int startY) {
        x = this.startX = startX;
        y = this.startY = startY;
    }

    public void chasePlayer(PacmanPlayer player, int[][] walls) {
        int playerX = player.getX();
        int playerY = player.getY();

        // Creates nodes for the ghost and player positions
        Node ghostNode = new Node(x, y);
        Node playerNode = new Node(playerX, playerY);

        // Get the path from the ghost to the player using A*
        List<Node> path = findPath(ghostNode, playerNode, walls);

        // Moves the ghost along the path
        if (path.size() > 1) {
            Node nextNode = path.get(1);
            
            // this adjusts the speed by moving twice as fast (the multiplier)
            x += (nextNode.getX() - x) * speedMultiplier;
            y += (nextNode.getY() - y) * speedMultiplier;
        }
    }

    private List<Node> findPath(Node start, Node goal, int[][] walls) {
        PriorityQueue<Node> openSet = new PriorityQueue<>();
        Set<Node> closedSet = new HashSet<>();

        openSet.add(start);

        while (!openSet.isEmpty()) {
            Node current = openSet.poll();

            if (current.equals(goal)) {
                
                List<Node> path = new ArrayList<>();
                while (current != null) {
                    path.add(current);
                    current = current.getParent();
                }
                Collections.reverse(path);
                return path;
            }

            closedSet.add(current);

            for (Node neighbor : getNeighbors(current, walls)) {
                if (closedSet.contains(neighbor)) {
                    continue;
                }

                int tentativeGScore = current.getG() + 1;

                if (!openSet.contains(neighbor) || tentativeGScore < neighbor.getG()) {
                    neighbor.setG(tentativeGScore);
                    neighbor.setH(heuristic(neighbor, goal));
                    neighbor.setParent(current);

                    if (!openSet.contains(neighbor)) {
                        openSet.add(neighbor);
                    }
                }
            }
        }

        return new ArrayList<>(); 
    }

    private List<Node> getNeighbors(Node node, int[][] walls) {
        List<Node> neighbors = new ArrayList<>();

        int[][] directions = { { 0, 1 }, { 0, -1 }, { 1, 0 }, { -1, 0 } };

        for (int[] dir : directions) {
            int newX = node.getX() + dir[0];
            int newY = node.getY() + dir[1];

            if (isValidMove(newX, newY, walls)) {
                neighbors.add(new Node(newX, newY));
            }
        }

        return neighbors;
    }

private boolean isValidMove(int newX, int newY, int[][] walls) {
    // Checks if the new position is within the allowed bounds and doesn't collide with walls
    int ghostRadius = 20; // Adjusts the value based on the size of the ghost

    int ghostLeft = newX;
    int ghostRight = newX + 2 * ghostRadius;
    int ghostTop = newY;
    int ghostBottom = newY + 2 * ghostRadius;

    // Checks if the new position collides with any walls
    for (int[] wall : walls) {
        int wallLeft = wall[0];
        int wallRight = wall[0] + wall[2];
        int wallTop = wall[1];
        int wallBottom = wall[1] + wall[3];

        if (ghostRight > wallLeft && ghostLeft < wallRight && ghostBottom > wallTop && ghostTop < wallBottom) {
            return false; // had a collision with wall
        }
    }

    // Checks if the new position is within the allowed bounds
    return newX >= 0 && newX + 2 * ghostRadius <= 600 && newY >= 0 && newY + 2 * ghostRadius <= 600;
}

    private int heuristic(Node a, Node b) {
        
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    void draw(Graphics g) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class Node implements Comparable<Node> {
        private int x, y;
        private int g, h; 
        private Node parent;

        public Node(int x, int y) {
            this.x = x;
            this.y = y;
            this.g = 0;
            this.h = 0;
            this.parent = null;
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }

        public int getG() {
            return g;
        }

        public void setG(int g) {
            this.g = g;
        }

        public int getH() {
            return h;
        }

        public void setH(int h) {
            this.h = h;
        }

        public Node getParent() {
            return parent;
        }

        public void setParent(Node parent) {
            this.parent = parent;
        }

        @Override
        public int compareTo(Node other) {
            
            return Integer.compare(g + h, other.g + other.h);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            Node other = (Node) obj;
            return x == other.x && y == other.y;
        }

        @Override
        public int hashCode() {
            return Objects.hash(x, y);
        }
    }

    public void reset() {
        // Resets the ghost's position
        x = startX;
        y = startY;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}